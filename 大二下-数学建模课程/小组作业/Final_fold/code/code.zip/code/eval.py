# -*- coding: utf-8 -*-
"""
Created on Sat Apr 26 22:46:22 2025

@author: Lenovo
"""

import os
import numpy as np
from numba import jit
from fastdtw import fastdtw
from scipy.spatial.distance import euclidean
# ======================
# 核心算法模块（Numba加速）
# ======================
@jit(nopython=True, cache=True)
def euclidean_fast(p1: np.ndarray, p2: np.ndarray) -> float:
    return np.sqrt((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)
@jit(nopython=True, cache=True)
def frechet_core(P: np.ndarray, Q: np.ndarray) -> float:
    n, m = P.shape[0], Q.shape[0]
    dp = np.full((n, m), np.inf)
    dp[0, 0] = euclidean_fast(P[0], Q[0])
    for i in range(1, n):
        dp[i, 0] = max(dp[i-1, 0], euclidean_fast(P[i], Q[0]))
    for j in range(1, m):
        dp[0, j] = max(dp[0, j-1], euclidean_fast(P[0], Q[j]))
    for i in range(1, n):
        for j in range(1, m):
            dp[i, j] = max(
                min(dp[i-1, j], dp[i-1, j-1], dp[i, j-1]),
                euclidean_fast(P[i], Q[j])
            )
    return dp[-1, -1]
# ======================
# 数据预处理模块
# ======================
def load_trajectory(filepath: str) -> np.ndarray:
    """带预处理的轨迹加载器[3](@ref)"""
    traj = []
    with open(filepath, 'r') as f:
        for line in f:
            parts = line.strip().split(',')
            if len(parts) >= 3:
                try:
                    traj.append([float(parts[1]), float(parts[2])])
                except (ValueError, IndexError):
                    continue
    return np.array(traj)
def adaptive_downsample(traj: np.ndarray) -> np.ndarray:
    if len(traj) <= 100:
        return traj
    target_length = max(100, len(traj)//20)
    step = max(1, len(traj)//target_length)
    return traj[::step]
# ======================
# 主计算模块
# ======================
def calculate_metrics():
    """多维度轨迹质量评估"""
    # 配置路径
    base_path = r"D:\BaiduNetdiskDownload\traj"
    train_files_path = os.path.join(base_path, "train_files.txt")
    train_dir = os.path.join(base_path, "train")
    masked_dir = os.path.join(base_path, "train_masked")
    marked_dir = os.path.join(base_path, "train_marked")
    # 路径校验
    required_paths = [train_files_path, train_dir, masked_dir, marked_dir]
    for path in required_paths:
        if not os.path.exists(path):
            raise FileNotFoundError(f"路径不存在: {path}")
    # 加载文件列表
    with open(train_files_path, 'r', encoding='utf-8') as f:
        target_files = [os.path.basename(l.strip()) for l in f if l.strip()]   
    # 初始化统计容器
    metrics = {
        'mse': [], 'rmse': [], 'mae': [],
        'frechet': [], 'dtw': [], 
        'valid_files': 0
    }
    for filename in target_files:
        try:
            # 加载四组轨迹数据
            train = load_trajectory(os.path.join(train_dir, filename))
            marked = load_trajectory(os.path.join(marked_dir, filename))
            masked = load_trajectory(os.path.join(masked_dir, filename))            
            # 数据预处理
            train = adaptive_downsample(train)
            marked = adaptive_downsample(marked)
            masked = adaptive_downsample(masked)            
            if len(train) < 2 or len(marked) < 2 or len(masked) < 2:
                continue
            # 计算五项指标
            # 1. MSE/RMSE/MAE计算[9,10](@ref)
            mse_lon = np.mean((train[:,0] - marked[:,0])**2)
            mse_lat = np.mean((train[:,1] - marked[:,1])**2)
            metrics['mse'].append((mse_lon + mse_lat)/2)
            metrics['rmse'].append(np.sqrt(metrics['mse'][-1]))
            metrics['mae'].append(np.mean(np.abs(train - marked)))            
            # 2. 弗雷歇距离[4](@ref)
            metrics['frechet'].append(frechet_core(train, marked))           
            # 3. DTW距离[8](@ref)
            dtw_dist, _ = fastdtw(train, marked, dist=euclidean)
            metrics['dtw'].append(dtw_dist)        
            metrics['valid_files'] += 1
        except Exception as e:
            print(f"处理文件 {filename} 失败: {str(e)}")
            continue
    # 计算全局均值
    return {
        "全局MSE均值": round(np.nanmean(metrics['mse']), 6),
        "全局RMSE均值": round(np.nanmean(metrics['rmse']), 6),
        "全局MAE均值": round(np.nanmean(metrics['mae']), 6),
        "全局frechet距离均值": round(np.nanmean(metrics['frechet']), 6),
        "全局DTW距离均值": round(np.nanmean(metrics['dtw']), 6),
        "有效文件数": metrics['valid_files']
    }
# ======================
# 执行入口
# ======================
if __name__ == "__main__":
    try:
        result = calculate_metrics()
        print("="*50)
        print("多维度轨迹质量评估报告".center(40))
        print("="*50)
        for k, v in result.items():
            print(f"{k.ljust(15)}: {v}")
    except Exception as e:
        print("程序运行失败:", str(e))
        print("请检查：\n1. 数据路径有效性\n2. 轨迹文件格式正确性\n3. 依赖库安装情况")